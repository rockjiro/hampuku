var app = new Vue({
    el: '#js-book-create',
    data: {
        message: 'Hello'
    }
})
;
